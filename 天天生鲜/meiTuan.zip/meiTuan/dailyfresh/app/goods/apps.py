from django.apps import AppConfig


class GoodConfig(AppConfig):
    name = 'goods'
